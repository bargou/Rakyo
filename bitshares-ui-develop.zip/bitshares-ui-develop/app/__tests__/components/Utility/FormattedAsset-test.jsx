import React from "react/addons";
var TestUtils = React.addons.TestUtils;
jest.dontMock("../../../app/components/Utility/FormattedAsset.jsx");

describe("<FormattedAsset>", function() {
    var FormattedAsset = require("../../../app/components/Utility/FormattedAsset.jsx");

});

