[# receive]
### 获取 BTS
为了从其他人或者交易所获得BTS，你只需要提供你的账户名: **{account}**

[# deposit-short]
### 充值/提现 数字资产
如果你要充值或提现资产，无论是法币或是来自其他区块链，你需要使用[桥接](introduction/bridges_gateways) 或 [网关](introduction/bridges_gateways) 服务来实现。你可以从下面找到一系列提供服务的服务商: