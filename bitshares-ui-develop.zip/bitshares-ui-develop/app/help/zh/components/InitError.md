[# connection-error]
无法获取到全节点的 websocket 连接

Possible reasons: TODO
- reason #1
- reason #2
