调整和设置你的债务及抵押物(保证金).

如果调低 {debt} 债务水平，将从 {borrower} 账户中扣除相应 {debt} 归还。
如果调高 {debt} 债务水平，只要 {borrower} 账户持有足够的 {collateral} 可供抵押冻结，新借入的 {debt} 将存入 {borrower} 账户中。

保证金可以增加或减少，只要抵押率超过维持保证金率。[更多信息](dex/shorting)
