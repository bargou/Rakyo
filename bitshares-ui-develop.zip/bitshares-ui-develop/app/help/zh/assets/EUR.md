[# summary]
### 资产 {symbol}

{description}  
发行人 {issuer}

欧元 (标识: €; 符号: EUR) 是欧元区参与国的官方货币。
