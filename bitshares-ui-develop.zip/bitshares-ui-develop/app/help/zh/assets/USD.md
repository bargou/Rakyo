[# summary]
### 资产 {symbol}

{description}  
发行人 {issuer}

美元 (标识: $; 符号: USD) 是美利坚合众国的官方货币。
