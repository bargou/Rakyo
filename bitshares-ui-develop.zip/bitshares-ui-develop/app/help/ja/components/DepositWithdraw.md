[# receive]
### BTSの受け取り
他の人や取引所からBTSを受け取るには、次のアカウント名を入力するだけです: **{account}**

[# deposit-short]
### コインの入出金
フィアットや他のブロックチェーンから資金を預け入れる、または引き出す場合は、[ブリッジ](introduction/bridges_gateways)または[ゲートウェイ](introduction/bridges_gateways)サービスを利用することができます。
