### Terimler

[İndexe Geri Git](index.md)