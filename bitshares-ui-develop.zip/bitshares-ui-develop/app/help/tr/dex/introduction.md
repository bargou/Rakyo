# Giriş

Merkezsiz borsa (kısaca *DEX*) , BitShares ekosisteminde 
alıp-satılan dijital mamüllerin doğrudan takas edilebilmelerini sağlar.

Merkezsiz bir borsanın , bariz geleneksel borsalardan bir takım avantajları vardır. 
Bunlardan kısaca bahsetmek istiyoruz. BitShares DEX'de hepsi mevcut olmasina 
rağmen o özellikleri tamamen ya da kısmen layığı ile kullanabilmek okuyucuya ve 
müşteriye kalmıştır.

* **Güçler Ayrılığı** : 
  IOU 'lari piyasaya sürme  ve sipariş defterlerine işleme görevinden aynı 
  kimsenin sorumlu olmasını gerektirecek bir sebep yoktur. BitShares'de işlem 
  emirlerin eşleştirilmesi işi protokol tarafından yürütülür, protokolün 
  işlemlere konu olan aktiflerle ilgili bilgisi yoktur, sadece işlem görür.
* **Genel Birleşik Emir/Sipariş Defteri** :
  BitShares evrensel olduğu için , internet erişimi olan herkes  DEX'i alım-satım için 
  kullanabilir. Bu, dünyanın likiditesini , merkezsiz/dağıtık alım-satım için tek bir emir 
  defterine getirir.
* **Neredeyse Herşeyi Alıp-Satabilirsiniz** :
  BitShares DEX varlığın muhteviyatını bilmez , dolayısı ile **her türlü**  eşleşme ticareti 
  yapılabilir. GÜMÜŞ:ALTIN gibi bazı eşleşmeler  az likidite sağlarken FOREX ticareti 
  için USD:EUR gibi eşleşmeler çok büyük hacimli işlem görür.
* **Limit Yok** :
  BitShares protokolünün sizin ticaret deneyiminizi sınırlaması mümkün değildir.
* **Merkezsiz** :
  DEX (merkezsiz borsa) tüm dünyaya dağıtıktır. Bölece tek kırılma noktası 
  olmadığı gibi bu BitShares borsasının ticaret için 7/24 açık olduğu anlamına 
  gelir, çünkü her zaman dünyada bir yerde vakit mutlaka gündüzdür. 
* **Güvenli** :
  Fonlarınız ve ticari işlemleriniz endüstriyel seviyedeki eliptik-eğri kriptografisiyle tamamen güvence altındadır. 
   Kimse siz izin vermedikçe fonlarınıza erişemez.
  Güvenliği daha da güçlendirmek amacıyla müşterilerimize emanet-escrow ve çoklu-
  imza planları düzenlemelerine imkan tanıyoruz.
* **Hızlı** :
  Diğer merkezsiz ağların tersine BitShares DEX gerçek-zamanlı ticarete
   imkan tanır , sadece ışık hızı ve gezegenin büyüklüğü 
  ile sınırlıdır.
* **Kanıtlanabilir Emir Eşleştirme Algoritması** :
  BitShares DEX i nadir kılan şeylerden biri de ispatlanabilir emir eşleştirme 
  algoritmasıdır.  Verilen bir takım işlem-emri  için her zaman bu emirlerin 
  kanıtlanabilir şekilde eşleştirilmiş olduğunu teyit edebilirsiniz.
* **Teminata Bağlanmış** :
  BitShares'in en büyük özelliklerinden biri de bitUSD, bitEUR, bitCNY gibi 
  *akıllıparalar*dır. Kolaylık olsun diye bu varlıklar cüzdan içerisinde USD,EUR,CNY 
  diye kısaltılmışlardır. Bu dijital kuponlar dayandıkları fiziksel varlıkla aynı değeri 
  temsil ederler. Yani bu cüzdandaki 1 USD nin değeri 1 dolardır ve o şekilde 
  ödenebilir. Bu kuponların hepsinin karşılığı olarak teminat olarak kitli tutulan ve anlık 
  fiyatında hesap görümü için mevcut olabilen, **BitShares'in şirket hisseleri (BTS)** 
   vardır.