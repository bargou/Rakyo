Memo anahtarı, memoların size ulaştığı yerdir, memoları deşifre edebilmeniz için açık anahtara ait özel anahtarın yönetimine sahip olmanız gerekir.

Bir açık/özel anahtar çifti kullanarak harcama yetkisi olmadan üçüncü şahıslara memolarınıza salt-okuma erişimi sağlayabilirsiniz.