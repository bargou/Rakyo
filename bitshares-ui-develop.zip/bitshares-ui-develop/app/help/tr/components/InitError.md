[# connection-error]
Ful noda websocket bağlantısı kuramadık.

Olası sebepler: TODO
- sebep #1
- sebep #2
