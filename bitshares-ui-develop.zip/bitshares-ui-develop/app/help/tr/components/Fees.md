# Ücretler

BitShares ekosistemi içerisinde her işleme tahsis edilmiş *bireysel* bir ücret vardır. 
Bu ücretler değişime tabidirler. Bununla birlikte, bunlar sadece hissedarların oylarıyla 
belirlenirler, böylece BitShares'in esas varlığı olan BTS hissedarlarının her biri 
ücretlerin ne olacağı konusunda söz sahibi olur. Eğer hissedarlar belli bir ücretin 
düşürülmesi konusunda fikir birliği sağlarlarsa o ücret blok zinciri tarafından otomatik 
olarak düşürülür. Blok zinciri parametrelerinin düzenlemesiyle ilgili teklifler kurul 
üyeleri tarafından yapılırlar. Bu üyeler hissedarlar tarafından oy kullanılarak seçilirler 
ve herhangi bir durumda, esneklik ve  reaksiyon kabiliyetini arttırırlar.