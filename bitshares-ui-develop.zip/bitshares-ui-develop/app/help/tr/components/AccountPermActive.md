Etkin izinler, bu hesaptaki fonları harcamaya izni olan hesapları belirler.

Etkin izinler kolay bir şekilde çok-imzalı bir düzen kurmak için kullanılabilirler, daha fazla bilgi için [izinler](accounts/permissions) bölümüne bakabilirsiniz.