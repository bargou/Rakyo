Bir aktif yaratmak için şunlar gerekli :
* Geçerli bir varlık sembolü
* 0 (sıfır)dan büyük maksimum arz

Hassasiyet , varlığın destekleyeceği ondalık hane sayısını belirler.

Varlık yaratmanın masraf ücreti öncelikle varlığa ait sembolün uzunluğuna bağlıdır. 

Ücretlerin nekadarını tutacağınızı da piyasa ücreti ile yüzde olarak belirtebilirsiniz.