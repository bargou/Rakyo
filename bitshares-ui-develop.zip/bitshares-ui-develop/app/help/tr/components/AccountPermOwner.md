Sahip izinleri hesap üzerinde kimin kontrolü olduğunu belirler. Sahipler tüm anahtarların yenilerini belirleyebilir ve herhangi hesap ayarını değiştirebilir.

Daha fazla bilgi için [izinler](accounts/permissions) .