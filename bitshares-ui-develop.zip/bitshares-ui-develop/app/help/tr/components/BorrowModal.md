Bu ileti arzu ettiğiniz borç ve teminatı belirlemenizi sağlar.

Eğer {debt} borç azaltılırsa {borrower} hesabından düşürülecektir.
Eğer {debt} borç artarsa  yeterli {collateral} teminat bulunması kaydıyla {borrower} hesabına yatırılacaktır.    

Asgari idame teminatı muhafaza edildiği sürece teminat eklenebilir yada eksiltilebilir.