### Oy Kullanma

BitShares'de oy kullanmak ağın hem gelişmesi hem de güvenliği için önemlidir. Eğer dilerseniz oy kullanma hakkınızı  sizin için oy kullanabilecek bir vekile devredebilirsiniz. Eğer vekil tayin ederseniz, manuel oylama etkisiz hale getirilecektir.