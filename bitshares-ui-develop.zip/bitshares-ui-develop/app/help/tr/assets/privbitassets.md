Özelleştirilmiş BitAktifler (Privatized BitAssets)
====================

Özelleştirilmiş BitAktifler  piyasa-sabitli-aktif çıkarmak isteyen fakat 
fiyatların tanıklar tarafından duyurulmasını istemeyen müşterilere hitab eder. Onun 
yerine, süren kimse *özelleştirilmiş* bitaktif yaratırken o aktif için özel olarak 
fiyatlarını duyurmaya müsadesi olan bir takım yetkililer belirleyebilir. Süren kimse
aktifle ilgili başka her türlü ücreti belirleyebilir ve kar elde edebilir.

Bu özellik gerçek-zamanlı fiyatlara erişimi olan ve teşhir ve hacim arttırmak  isteyen 
borsalar ve kuruluşlar için ayrıca ilgi çekicidir.