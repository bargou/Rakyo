# Piyasa Sabitli Aktifler (MPA-Market Pegged Assets)

Bitcoin'e benzeyen özelliklerde ve avantajlarda, amerikan Doları gibi tüm dünya
tarafından benimsenmiş bir parayla pariteyi koruyabilen bir kripto-paranın
 sansürsüz ve kolay bir ticaret için çok faydası vardır. Bu, BitShares'in 
piyasaya  sabitli varlıkları (MPA) sayesinde mümkün olur. Bunlar, serbestçe 
alıp-satılabilen yeni  bir tür dijital varlıklardır. Bunların değerleri, fark-kontratı (CFD) yöntemiyle
dayandıkları geleneksel varlıkların değerlerini takip etmek üzere dizayn edilmişlerdir. 

*AkıllıPara* (eşanlamı MPA) , değerinin  *daima*  100% yada daha fazlası BitShares'in 
 ana para birimi (BTS) ile desteklenen bir kripto-paradır. Bu *AkıllıParalar* herhangi bir 
zamanda bir fark-kontratı (CFD) içinde *teminat* olarak BTS'ye dönüştürülebilirler .

Teminatla desteklenen FK'nı andırmalarına rağmen PSV'leri nadir yapan şey 
onların  karşı taraf riskinden muaf olmalarıdır. Bunun mümkün olması için teminatı 
güvence  altına alma ve hesap görme işlemleri ağın  kendi sorumluluğuna bırakılmıştır  
(yazılım protokolüyle uygulanarak) . Bu konunun detayları aşağıda
anlatılacaktır.

Bu, piyasaya-sabitli-varlıkların mevcut bir alt kümesidir:
* BitUSD
* BitCNY
* BitEUR
* BitGOLD
* ...