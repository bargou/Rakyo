[# summary]
### Aktif {symbol}

{description}  
Piyasaya süren {issuer}

Amerikan Doları (işeret: $; sembol: USD $) ABD'nin resmi para birimidir.