[# summary]
### Aktif {symbol}

{description}  
Piyasaya süren {issuer}

Euro (işaret: €; sembol: EUR) Avrupa bölgesindeki katılımcı ülkelerin  resmi para birimidir.
