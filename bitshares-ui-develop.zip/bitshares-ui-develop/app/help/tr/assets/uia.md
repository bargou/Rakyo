# Kullanıcı Sürümü Aktifler (UIA-User Issued Assets)

Daha önce bahsedilen *piyasaya sabitli varlıkların* yanısıra , BitShares bireylere ve 
şirketlere, hayal edebilecekleri herşeye ait  kendi kuponlarını yaratma ve piyasaya 
sürme imkanı verir. Kullanıcı Sürümü Varlıklar (UIA) için potansiyel kullanım alanları 
sayısızdır. Bir tarafta UIA'ler müşterilerin telefonlarına konser girişlerinde 
kullanabilecekleri basit organizasyon biletleri olarak yüklenebilirler. Diğer tarafta ise 
kitle fonlaması, mülkiyet takibi , ya da hisse şeklinde şirket özsermayesi satışında bile 
kullanılabilirler.

Tabiiki, her tür kupona uygulanan kurallar çeşitlidir  ve her yetki bölgesinde farklılık 
gösterir. Dolayısıyla BitShares,  varlıklar piyasaya sürülürken , piyasaya süren kişinin 
geçerli kanunlar çerçevesinde korunmasına yardımcı olacak araçlarla gelir -kanunların 
böyle varlıklara zaten izin verdiğini farz ediyoruz.