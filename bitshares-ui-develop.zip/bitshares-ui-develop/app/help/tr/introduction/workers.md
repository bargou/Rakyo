# Emekçiler

Emekçiler maaş karşılığında  hizmet veren tekliflerdir, maaşlarını blok zincirinden alırlar. Bir emekçi teklifi en azından aşağıdaki bilgileri kapsamalıdır :

* Bir başlangıç ve bitiş tarihi
* Gündelik bir ücret
* Maksimum bir toplam maaş

Emekçi teklifinin daha detaylı anlatıldığı bir web sayfasına da bağlantı sunmalıdır.

Emekçi tekliflerine verilen oylar pozitif yada negatif olabilirler, yani beğenmediğiniz bir teklife red oyu kullanabilirsiniz.

## Emekçi bütçesi mekanizması
Emekçilerin ücretleri, ilk-gelen ilk-çalışır prensibiyle günlük sabit bir bütçeden para tükenene kadar ödenir. Nasıl işlediğini görmek için şu örneğe bakın:

* Tüm Emekçiler için günlük toplam bütçe 400 bin BTS olsun
* Her biri günlük 100k BTS talep eden toplam oyların pozitif olduğu 5 emekçi teklifi

Oyların çoğuna sahip 4 emekçinin her birine günlük 100 bin BTS ödenecek, fakat ödemeler tamamlandığında emekçi bütçesi tükenmiş olacak. O yüzden 5. emekçiye hiç bir şey ödenmeyecek.
