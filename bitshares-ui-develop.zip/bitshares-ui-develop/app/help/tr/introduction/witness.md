# Tanık

Tanıklar yeni bloklar inşa etmek suretiyle blokzincirine çalışan kimselerdir.
Her tanık, hissedarlar tarafından onaylanır ve tasdikli işlemlerden bloklar inşaa eder 
ve imzalar. Ağın içinde gerçekleşen her işlem en sonunda tüm tanıklar tarafından 
tasdik  edilmek zorundadır.

## Mutabakat Mekanizması

Kimin tam olarak hangi anda blok *ürettiği* , *Delegated Proof of Stake* 
(Yetkilendirilmiş-vekil-pay-ispatı) denilen mutabakat mekanizmasıyla belirlenir. 
Esasında, BitShares hissedarları (elinde BTS kuponu olan)  tercih edilen blok 
üreticilerine blokzincirinde oy verebilirler. O *tanıklar* adı verilen, en çok oyu alan 
kimselerin blokları üretmelerine müsade edilir.