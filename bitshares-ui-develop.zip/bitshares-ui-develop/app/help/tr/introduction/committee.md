#Kurul

Kurul, hissedarlar tarafından onaylanan kişilerden oluşan ve bazı ticari 
parametreleri belirleyen bir gruptur. Bu parametrelerden bazıları şunlardır : 

* işlem ve alım-satım ücretleri
* blok büyüklüğü ve blok aralıkları gibi blokzinciri parametreleri 
* nakit iade oranları ve vesting periodları gibi  parametreleri 
		gibi.