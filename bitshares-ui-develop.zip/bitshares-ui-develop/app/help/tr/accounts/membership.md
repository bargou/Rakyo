# Üyelik

BitShares'deki hesaplar üç gruba ayrılırlar . Biz kullanıcılara dilerlerse hesaplarını VIP
gibi bir statüye yükseltmelerine ve ilave özelliklerden ve indirimlerden 
faydalanmalarına imkan tanıdık.

## Üye-Olmayanlar

*Normal*  hesap *üye-olmayan* bir hesaptır.

## Ömür-boyu Üyeler

Ömür-boyu-üyelerinin ödediği her işlem ücretinin belirli bir yüzdesi kendilerine iade 
edilir ve kaydını yaptıkları ya da getirdikleri üyelerden komisyon geliri kazanmaya 
hak kazanırlar. Ömür-boyu-üyelikle alakalı kurul tarafından belirlenmiş belli miktarda 
tek-seferlik bir ücret vardır.

## Yıllık Üyeler

Ömür-boyu-üyelik eğer çok fazla gelirse , bir yıl süreli tek-seferlik düşük bir bedel 
karşılığında yıllık abone olarak bir sonraki seneye de aynı iadeyi 
alabilirsiniz.

### Ücret Paylaşımı

Getirdiğiniz hesap her işlem ücreti ödediğinde o ücret birçok farklı hesap arasında 
pay edilir. Ağımız bir kısmını alır , hesabı getiren ömür-boyu-üye de diğer kısmını alır.
Hesabı getiren üye bir kısım pay alır.

Kayıtçı , hesabın ağımıza kaydı yapılırken işlem ücretini ödeyen hesaptır. Kayıtçı 
ücretin geri kalan kısmını kendisi ve bağlantılarıyla nasıl pay edeceğine kendisi karar 
verir.

### Bekleyen Ücretler

Ödenen ücretler sadece ağımız, getirenler, ve kayıtçılar arasında her bakım aralığında 
bir kez pay edilir.
                 
### Hak Edilen Ücretler

Çoğu ücretler anında ödenmesine rağmen , bir limitin üzerindeki ücretler (mesela 
üyeliğinizi yükseltmek için ödediğiniz ya da paralı hesap kaydetmek için ödediğiniz 
ücretler) kurul tarafından belirlenen bir kaç gün boyunca haciz altında tutulabilirler.