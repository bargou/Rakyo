# Hesaplar

Şu ana kadar farkkettiğiniz gibi, bu blokzinciri teknolojisi bir hesap adı kaydetmenizi
mecbur kılar. Bunun bir çok avantajı vardır : Gelişmiş ölçeklenebilirlik bir yana,
biz bu şekilde , kimlik bilgilerini , işlemleri yetkilendiren imzalardan ayırmış oluyoruz.
Uygulamada , *bir hesap adına sahip olmak*  *o hesaba ait fonları*  harcayabilmekten 
bağımsızdır. Dahası her iki hak da (biz bunlara *izinler* diyoruz)  *ağırlıklar* ve 
*eşikler* kullanılarak gelişigüzel karmaşık insan ilişkileri (biz bunlara "yetkiler" 
diyoruz) arasında  paylaştırılabilirler.