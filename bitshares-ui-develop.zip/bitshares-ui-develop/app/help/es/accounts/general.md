# Cuentas

Como ya se habrá notado, esta tecnología blockchain requiere que usted
registre un nombre de cuenta. Esto trae numerosas ventajas. Además de incrementar
la escalabilidad, hemos separado la identidad de la firma autorizante
 de las transacciones. En la práctica, *ser propietario de una cuenta* es independiente de poder
*utilizar sus fondos". Adicionalmente, ambos derechos (que llamamos "permisos") pueden
combinarse en una compleja relación arbitraria entre personas (que llamamos "autoridades")
usando los parámetros *peso* y *humbral*.