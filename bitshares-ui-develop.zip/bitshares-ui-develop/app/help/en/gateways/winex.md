# Winex Gateway Service

Winex is a gateway service built on the Bitshares Exchange. A gateway service is responsible for moving cryptocurrencies to and from the Bitshares Exchange. They support a wide range of popular assets. You can easily identify those supported by Winex because they are prefixed with the word WIN.*. For example WIN.EOS etc.

## Website
[https://exchange.winex.pro/](https://exchange.winex.pro/)

## Support
- Ask For Help：support@winex.pro
