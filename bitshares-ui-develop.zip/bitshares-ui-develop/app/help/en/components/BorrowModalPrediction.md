This is a binary prediction market.

The collateral ratio of this market is 1:1.
