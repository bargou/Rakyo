Owner permissions define who has control over the account. Owners may overwrite all keys and change any account settings.

See [permissions](accounts/permissions) for more details.