Active permissions define the accounts that have permission to spend funds for this account.

They can be used to easily setup a multi-signature scheme, see [permissions](accounts/permissions) for more details.