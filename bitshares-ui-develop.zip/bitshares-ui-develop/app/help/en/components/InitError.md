[# connection-error]
We couldn't establish websocket connection to a full node.

Possible reasons: TODO
- reason #1
- reason #2
