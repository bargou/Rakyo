[# receive]
### Receiving BTS
In order to receive BTS from another person or from an exchange, simply give them your account name: **{account}**

[# deposit-short]
### Depositing or withdrawing coins
If you want to deposit or withdraw funds, either in fiat or from other blockchains, you may use a [bridge](introduction/bridges_gateways) or [gateway](introduction/bridges_gateways) service to do so.
