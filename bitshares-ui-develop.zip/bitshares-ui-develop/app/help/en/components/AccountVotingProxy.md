If you don't fully understand the roles of Witnesses, Committee Members and Workers, you may elect to choose a Proxy. A proxy is an account that you trust to make decisions about the Bitshares network on your behalf. You may find people proposing to act as proxies in the BitShares forum at [BitSharestalk](https://bitsharestalk.org/index.php/board,75.0.html). Additionally, you may choose from the list below, or you can manually enter any account you choose.

**Be sure to select publish changes above once you've made your selection**.
