The memo key is where you receive memos, in order to decode the memos you need to control the private key for the public key.

By using a public/private key pair without spending authority, you may give read-only access to your memos to third parties.
