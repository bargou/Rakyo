[# summary]
### Asset {symbol}

{description}

Issued by: {issuer}

The Euro (sign: €; symbol: EUR) is the official currency of participating countries in the Europ zone.
