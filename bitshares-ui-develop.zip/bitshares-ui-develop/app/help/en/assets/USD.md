[# summary]
### Asset {symbol}

{description} 
 
Issued by: {issuer}

The United States dollar (sign: $; symbol: USD) is the official currency of the United States of America.
