Privatized BitAssets
====================

Privatized BitAssets serve those customers that would like to issue a market
pegged asset but do not want the witnesses to publish the prices. Instead, when
creating a *privatized* bitasset, the issuer can define a set of authorities that
are allowed to publish the price for that particular asset. The issuer can
further define all kinds of fees involving this asset and make a profit.

This feature is of particular interest for exchanges and institutes that have
access to real-time prices and would like to increase exposure and volume.
