import counterpart from "counterpart";
export default counterpart;
