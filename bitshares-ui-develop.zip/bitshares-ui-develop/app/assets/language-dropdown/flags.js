// Core asset
require("file-loader?name=language-dropdown/EN.[ext]!./img/US.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/FR.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/TR.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/ZH.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/DE.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/IT.png");
require("file-loader?name=language-dropdown/KO.[ext]!./img/KR.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/ES.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/RU.png");
require("file-loader?name=language-dropdown/[name].[ext]!./img/JA.png");
