const locales = ["de", "es", "fr", "ko", "it", "tr", "ru", "zh", "ja"];

module.exports = locales;
