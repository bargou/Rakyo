import Alt from "alt";
var alt = new Alt();

// DEBUG log all action events
// alt.dispatcher.register(console.log.bind(console, 'alt.dispatcher'))

export default alt;
