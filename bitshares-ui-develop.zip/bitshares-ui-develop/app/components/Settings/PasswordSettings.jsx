import React from "react";
import WalletChangePassword from "../Wallet/WalletChangePassword";

export default class PasswordSettings extends React.Component {
    render() {
        return <WalletChangePassword />;
    }
}
